<template>
    <div class="container">
      <client-only placeholder="loading...">
        <Drawer />
      </client-only>
      <NuxtPage />
      <Footer />
    </div>
</template>
