<template>
    <div class="appTitle mt-5 mb-2">
        <NuxtLink to="/">Currating and visualizing a library</NuxtLink>
    </div>
</template>

