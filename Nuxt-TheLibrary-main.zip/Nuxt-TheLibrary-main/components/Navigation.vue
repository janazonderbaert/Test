<template>
    <div>
        <nav class="mb-2">
        <ul>
            <li class="pr-2"><NuxtLink to="/about">About</NuxtLink></li>
            <li class="pr-2"><NuxtLink to="/books">Books</NuxtLink></li>
        </ul>
        </nav>
    </div>
</template>

<style>
li{ 
    display: block;
}
</style>
