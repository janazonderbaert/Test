<template>
  <div>
    <p class="text-5xl font-semibold">
      This example starts from a yearly currated list of books from the library. The dataset is based on the dataset of LIMO and accessible as a JSON file.
    </p>
    <div class="buttonBack font-bold">
      <NuxtLink to="/books">Access to the collection</NuxtLink>
    </div>
  </div>
</template>
