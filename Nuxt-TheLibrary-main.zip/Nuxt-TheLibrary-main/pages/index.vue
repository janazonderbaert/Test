<template>
<div>
    <p class="pageTitle">Curating and visualizing a Library</p>
    <p class="text-2xl">
        This example starts from a yearly currated list of books from the library. The dataset is based on the dataset of LIMO and accessible as a JSON file.
    </p>
    <div class="buttonBack font-bold">
        <NuxtLink to="/books">Access to the collection</NuxtLink>
    </div>
</div>
</template>
